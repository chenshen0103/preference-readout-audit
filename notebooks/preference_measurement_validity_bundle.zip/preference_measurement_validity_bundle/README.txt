Preference Measurement Validity - notebook bundle
=================================================

Just READ:  open preference_measurement_validity.ipynb - all figures
and printed numbers are already embedded; no execution needed.

RE-RUN (optional):
  pip install numpy matplotlib jupyter
  jupyter lab preference_measurement_validity.ipynb
Run from this folder (the notebook resolves data paths relative to
its working directory: ./analysis and ./report/data).

Data files are exactly the saved outputs of the analyses described
inside; nothing here re-runs model inference.

EXPERIMENT SCRIPTS are included for the record (analysis/*.py and
report/data/*.py): they are what PRODUCED the data files. Re-running
them needs the full setup (4x V100, google/gemma-4-31B-it fp16 via
NNsight; behavioral scripts additionally need the patched
emergent-values working copy at upstream commit 5e5966d). The
notebook itself never calls them.
